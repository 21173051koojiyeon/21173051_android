package com.example.a11stapp;

public class MovieList {
    MovieListResult boxOfficeResult;
}
